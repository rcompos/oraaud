#!/usr/bin/env ksh
#
#
#  Driver for the scp_audit install process 
#
#  This is divided into parts. 
#
#  Script 1 - config_scp_ora_audit.sh
#   1   create the ssh keys and populate to the NetF server 
#   2   update the Inittab to keep the process running. 
#  Script 2 - Copy over the scp-audit.sh 
#   1  copy over the script 
#   2  kill off any processes that are running now. 
#  Script 3 - turn on Oracle Audit processing 
#  1 - find the DBs installed on the server 
#  2 - check if Audit is already on 
#  3 - Turn on Audit if required 
#     for each DB  run oracle_audit11g.os.non_syslog.sh -o oracile_sid 

export Script_name=$(basename $0) 
mkdir /home/oracle/system/audit/.audit 2>/dev/null
chown oracle.oinstall /home/oracle/system/audit/.audit
chmod 700 /home/oracle/system/audit/.audit
umask 002
export LOG=/home/oracle/system/audit/.audit/install_ora_audit.sh
[[ -f $LOG ]] && mv $LOG /tmp/$LOG.$(date "+%Y-%m-%d").$(date "+%H%M%S")
touch $LOG
chown oracle.oinstall $LOG
chmod 700 $LOG

{
   function set_env {
     echo "$Script_name: The script name is $Script_name   Log is $LOG "
     umask 0022
   }
   function error_exit {
      echo "  ERROR $2" | tee -a $LOG
      exit $1
   }
   function check_required_files {
      echo "$Script_name:  Checking for required files "
      # check for required scripts. 
      Chk_Files=" config_scp_ora_audit.sh
         install_srpt_audit.sh
         oracle_turnon_audit.sh 
         oracle_audit.11g.os.non_syslog.sh
         scp_audit.sh "
      FOUND_FLAG=FALSE
      for file in $Chk_Files; do 
         if [[ -r $file ]]; then 
            echo "Sscript_name: The file $file is readable" >> $LOG
         else 
            echo "$Script_name: ERROR -- The file $file is missing or unreadable"
            FOUND_FLAG=TRUE 
         fi 
      done 
      echo " "
      if [[ $FOUND_FLAG == TRUE ]]; then 
         echo  "$Script_name:  ERROR -- Some files or permissions were missing"
         exit 1
      fi
      echo "$Script_name: == Check required files" 2>&1
      if [[ ! -s /tmp/usfs_local_sids ]]; then
         cat >   /tmp/usfs_local_sids <<\EOF
#!/usr/bin/env ksh
#
#  FILE:
#  VERSION:  
#  DATE:  
#
# Purpose:  List instance names on local host.
#
# Attention: Test any changes in bash, pdksh, and ksh93.
#
# Requires:
#    /etc/oratab
# Results:
#    Found ORACLE_SIDs are echoed to stdout
#
# Suggested client invocation:   SIDS=$(fs_local_sids)

TAB=$(echo -e "\t")
# Turn off shell history subsititution for exclamation point
ps h -p $$ | grep -q bash && set +H

# Check for local host being a RAC server
INSTNBR=$( ps -ef | sed "/asm_pmon_+AS[M]/!d;s|.*asm_pmon_+AS[M]||" )
if [[ -z "$INSTNBR" ]]; then
   INSTNBR=$( sed "/^[ $TAB]*#/d; /^+ASM[0-9]:/!d; s|+ASM\([0-9]*\):.*|\1|" /etc/oratab )
fi
if [[ -n "$INSTNBR" ]]; then
   # This server is a RAC node
   # It is an error if a dbname ends with a numeral in oratab
   SIDS=$(cat /etc/oratab | grep -E -v "^[  ]*$|^#|^\+:[nN]|ASM|\*" | cut -f1 -d: | \
      sed "s|$|$INSTNBR|")
else
   # This server is a Stand-Alone server
   SIDS=$(cat /etc/oratab | grep -E -v "^[  ]*$|^#|^\+:[nN]|ASM|\*" | cut -f1 -d:)
fi
echo "$SIDS"
EOF
         chown oracle.oinstall /tmp/usfs_local_sids 
         chmod 755        /tmp/usfs_local_sids 
      fi
      if [[ ! -s /tmp/oraenv.usfs ]]; then
         cat >   /tmp/oraenv.usfs <<\EOF
#  FILE:
#  VERSION: 
#  DATE:  
#
#
# Purpose: Source this file to get an ORACLE_HOME by looking up ORACLE_SID in /etc/oratab
#          Sets ORACLE_HOME regardless of RAC or stand-alone, 10g or 11g
#          Calls the standard /usr/local/bin/oraenv
#
# Attention: Test any changes in bash, pdksh, and ksh93.
#
# Requires:
#   ORACLE_SID
#
# Results:
#   Sets envars based on ORACLE_SID:
#     ORACLE_HOME, PATH, LD_LIBRARY_PATH, etc.
#   Setting TNS_ADMIN and/or modifying PATH is left to the user

TAB=$(echo -e "\t")
# For bash, turn off shell history substitution for exclamation point
ps h -p $$ | grep -q bash && set +H

# Determine node/instance number for RAC nodes
INSTNBR=$( ps -ef | sed "/asm_pmon_+AS[M]/!d;s|.*asm_pmon_+AS[M]||" )
if [[ -z "$INSTNBR" ]]; then
   INSTNBR=$( sed "/^[ $TAB]*#/d; /^+ASM[0-9]:/!d; s|+ASM\([0-9]*\):.*|\1|" /etc/oratab )
fi

# Preserve current value of ORACLE_SID
orig_ORACLE_SID=$ORACLE_SID

# If this server is a RAC node, strip instance number
# from ORACLE_SID before calling oraenv
if [[ -n "$INSTNBR" ]]; then
   export ORACLE_SID=${ORACLE_SID%${INSTNBR}}
fi

orig_ORACLE_BASE=$ORACLE_BASE
# Call oraenv to set PATH, ORACLE_HOME,
#  LD_LIBRARY_PATH (for RDBMS servers), etc.
# Setting TNS_ADMIN and/or modifying PATH is left to the user
which dbhome 2> /dev/null || PATH=$PATH:/usr/local/bin/
ORAENV_ASK=NO
. /usr/local/bin/oraenv < /dev/null

# Restore original value of ORACLE_SID
export ORACLE_SID=$orig_ORACLE_SID

# If ORACLE_HOME was set to the ~oracle default, then oraenv failed;
#  try again with original value of ORACLE_SID as restored above
if [[ "$ORACLE_HOME" == ~oracle ]]; then
   . /usr/local/bin/oraenv
fi
ORACLE_BASE=$orig_ORACLE_BASE
EOF
         chown oracle.oinstall /tmp/oraenv.usfs
         chmod 755        /tmp/oraenv.usfs
      fi
      echo "$Script_name: .. Pass"
   }
   function set_SIDS {
      echo "$Script_name: >==Setting SIDS envar"
      export SIDS=$(
         for ORACLE_SID in $(. /tmp/usfs_local_sids); do
            ps -ef | grep -q [o]ra_pmon_$ORACLE_SID && echo $ORACLE_SID
         done | tr '\n' ' ')
      if [[ -z $SIDS ]]; then 
         echo "$Script_name:  >== No active DBs found -- Abort "
         exit 1 
      fi   
      echo "$Script_name: >== SIDS found active $SIDS "
   }
   function func_oracle_turnon_audit {
      echo "$Script_name:== Conditionally do SQL audit statements based on audit_sys_operations=FALSE"
      #  if Value is FALSE  then audit is not on. 
      # Need to run the audit turn on script.  
   
      export SQLFILE1=/tmp/DG_DB0029a.sql
      cat > $SQLFILE1 <<\EOF
         select value from v$parameter where name = 'audit_sys_operations'
   
         l
         r
EOF
      chmod 777 /tmp/DG_DB0029a.sql
      #
      #  if Value is FALSE  then audit is not on. 
      # Need to run the audit turn on script.  
      #
      #
      for ORACLE_SID in $SIDS; do
         export ORACLE_SID
         echo "Oracle_SID=$ORACLE_SID"
         ORACLE_HOME=$(. /tmp/oraenv.usfs >/dev/null 2>/dev/null; \
            echo $ORACLE_HOME)
         echo ORACLE_HOME=$ORACLE_HOME >> $LOG
         [[ ! -d $ORACLE_HOME ]] && echo "couldn't determine ORACLE_HOME for ORACLE_SID=$ORACLE_SID"
         (
               export ORACLE_SID=$ORACLE_SID;
               . /tmp/oraenv.usfs;
               PATH=$ORACLE_HOME/bin:$PATH;
               sqlplus "/ AS SYSDBA" < $SQLFILE1) \
            > $VERBOSE.$ORACLE_SID.log 2>&1
         echo "== $TESTNUM ==" >> $LOG
         cat $VERBOSE.$ORACLE_SID.log >> $LOG
         grep ORA-[0-9][0-9][0-9][0-9][0-9] $VERBOSE.$ORACLE_SID.log \
            | grep -Ev '^ORA-00000|^ORA-01920' && \
            error_exit 5 "ERROR running test $TESTNUM"
   
         if grep -i ^TRUE $VERBOSE.$ORACLE_SID.log; then 
            echo " Is set to true " >> $LOG  # Audit already turned on
         else 
            echo " Is set to False - Run the oracle_audit.11g.os.non_syslog.sh with $ORACLE_SID " >> $LOG  # need to turn Audit on
            ksh oracle_audit.11g.os.non_syslog.sh -o $ORACLE_SID
         fi
      done
   }
   function func_oracle_turnon_audit_backout {
      echo "$Script_name:== Backout oracle_audit.11g.os.non_syslog.sh for each SID"
      for ORACLE_SID in $SIDS; do
         export ORACLE_SID
         ksh oracle_audit.11g.os.non_syslog.sh -o $ORACLE_SID -b
      done
   }
   function bounce_process_for_scp_audit_sh {
      echo "$Script_name:== Bounce process for scp_audit.sh"
      if [[ ! -s /home/oracle/system/audit/scp_audit.sh ]]; then
         echo "$Script_name: scp_audit.sh does not exist - "
         touch /home/oracle/system/audit/scp_audit.sh
      fi
 
      chown oracle.oinstall /home/oracle/system/audit/scp_audit.sh 
      chmod 700 /home/oracle/system/audit/scp_audit.sh 

      Liner=$(ps -ef | grep scp_audit.sh | grep -v grep | awk '{print $2}' | tr '\n' ' ' )
      if [[ -z $Liner ]]; then 
         echo "$Script_name:  No current running processes"
      else
         kill -9 $Liner
      fi
   }
   function call__config_scp_ora_audit_sh {
      echo "$Script_name:== Call external script config_scp_ora_audit.sh"
      /home/oracle/system/audit/config_scp_ora_audit.sh || error_exit 1 "couldn't configure scp options by calling script /home/oracle/system/audit/config_scp_ora_audit.sh"
   }
   function sign_signature {
      echo "$Script_name:== Create signature file"
      mkdir -p /home/oracle/system/tivoli_signatures/
      echo "Oracle-SCP_AUDIT.SH script update,109,/home/oracle/system/tivoli_signatures/scp_audit_update.sig" >/home/oracle/system/tivoli_signatures/scp_audit_update.sig
   }

   ###########################################################################
   # MAIN
   set_env
   check_required_files
   set_SIDS
   while getopts ho: option
   do
      case "$option"
      in
         h) usage_exit 1;;
         b) export BACKOUT_FLAG="TRUE";;
        \?)
            eval print -- "ERROR:" '$'$( echo $OPTIND - 1 | bs ) \
                          "option is not a supported switch."
            usage_exit 1;;
      esac
   done

   if [[ -n $BACKOUT_FLAG ]]; then
      func_oracle_turnon_audit_backout
   else
      func_oracle_turnon_audit
      call__config_scp_ora_audit_sh
      bounce_process_for_scp_audit_sh
      sign_signature
   fi

   echo "$Script_name:  SCRIPT COMPLETED SUCCESSFULLY $(date) Log is $LOG" 
} 2>&1 | tee $LOG
   
