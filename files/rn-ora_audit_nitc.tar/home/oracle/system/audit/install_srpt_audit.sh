#!/usr/bin/env ksh
# 
# Install the scp_audit.sh updates
#   - save the old one to /tmp/
#   - copy in the new one 
#   - kill the current running script
#   - let the auto restart process start the new one. 
#
#  
#  VERSION:  1.0
#  DATE:  12/15/2014
#   
#   Author: - Henry Steinhauer
#
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted
#
# Purpose:
#     Update the script that copies the Oracle Audit Logs
#     Write Oracle audit logs remotely.
#
function Check_Uid {
   if [ $(whoami) != oracle ]; then
      echo "Error: You must be user oracle to run this script."
      exit 1
   fi
}
export Script_name=$(basename $0)
echo " $Script_name: Check Root Userid " 
Check_Uid
echo " $Script_name: Passed Check Root Userid "

if [[ ! -s /home/oracle/system/audit/scp_audit.sh ]]; then
   echo "$Script_name: scp_audit.sh does not exist - "
    touch /home/oracle/system/audit/scp_audit.sh
    fi
 
#cp scp_audit.sh /home/oracle/system/audit/scp_audit.sh

chown oracle.dba /home/oracle/system/audit/scp_audit.sh 
chmod 700 /home/oracle/system/audit/scp_audit.sh 


Liner=$(ps -ef | grep scp_audit.sh | grep -v grep | awk '{print $2}' | tr '\n' ' ' )
 if [[ -z $Liner ]]; then 
  echo "$Script_name:  No current running processes"
 else
  kill -9 $Liner
 fi
 
echo " $Script_name: Updated and restarted scp_audit.sh  "

#
# Create Tivoli Signature file for tracking this change. 
#
mkdir -p /home/oracle/system/tivoli_signatures/
echo "Oracle-SCP_AUDIT.SH script update,109,/home/oracle/system/tivoli_signatures/scp_audit_update.sig" >/home/oracle/system/tivoli_signatures/scp_audit_update.sig

echo " $Script_name: Finished the scp_audit.sh update "
