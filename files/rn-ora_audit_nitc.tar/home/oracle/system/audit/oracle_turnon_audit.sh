#!/usr/bin/env ksh
#  test if Oracle Audit is on or not. 
#
#

# 
#   Use some common scripts from the disa-stig   scripts.  
#
#================================================================
# create Oracle_SIDs to process against
#================================================================
function set_SIDS {
   echo "$Script_name: >==Setting SIDS envar" | tee -a $VERBOSE
   export SIDS=$(
      for ORACLE_SID in $(. /tmp/usfs_local_sids); do
         ps -ef | grep -q [o]ra_pmon_$ORACLE_SID && echo $ORACLE_SID
      done | tr '\n' ' ')
    if [[ -z $SIDS ]]; then 
      echo "$Script_name:  >== No active DBs found -- Abort " | tee -a $VERBOSE 
      touch /tmp/ora_audit_abort.txt   
      exit 1 
    fi   
   echo "$Script_name: >== SIDS found active $SIDS " | tee -a $VERBOSE
}

#================================================================
# Set envars
#================================================================
function set_envars {
   echo "$Script_name: ==Setting initial envars"
   export System=$(hostname)
   export VERBOSE=/tmp/$System.$(date "+%Y-%m-%d").$(date "+%H%M%S").Oracel11g_AuditOn.Verbose.txt 
    touch $VERBOSE 
   chown oracle.dba $VERBOSE 
   chmod 777 $VERBOSE 
   }
#================================================================
# Check required files
#================================================================
function check_required_files {
   echo "$Script_name: == Check required files" 2>&1 | tee -a $VERBOSE
   if [[ ! -s /tmp/usfs_local_sids ]]; then
      cat >   /tmp/usfs_local_sids <<\EOF
#!/usr/bin/env ksh
#
#  FILE:
#  VERSION:  
#  DATE:  
#
# Purpose:  List instance names on local host.
#
# Attention: Test any changes in bash, pdksh, and ksh93.
#
# Requires:
#    /etc/oratab
# Results:
#    Found ORACLE_SIDs are echoed to stdout
#
# Suggested client invocation:   SIDS=$(fs_local_sids)

TAB=$(echo -e "\t")
# Turn off shell history subsititution for exclamation point
ps h -p $$ | grep -q bash && set +H

# Check for local host being a RAC server
INSTNBR=$( ps -ef | sed "/asm_pmon_+AS[M]/!d;s|.*asm_pmon_+AS[M]||" )
if [[ -z "$INSTNBR" ]]; then
   INSTNBR=$( sed "/^[ $TAB]*#/d; /^+ASM[0-9]:/!d; s|+ASM\([0-9]*\):.*|\1|" /etc/oratab )
fi
if [[ -n "$INSTNBR" ]]; then
   # This server is a RAC node
   # It is an error if a dbname ends with a numeral in oratab
   SIDS=$(cat /etc/oratab | grep -E -v "^[  ]*$|^#|^\+:[nN]|ASM|\*" | cut -f1 -d: | \
      sed "s|$|$INSTNBR|")
else
   # This server is a Stand-Alone server
   SIDS=$(cat /etc/oratab | grep -E -v "^[  ]*$|^#|^\+:[nN]|ASM|\*" | cut -f1 -d:)
fi
echo "$SIDS"
EOF
      chown oracle.dba /tmp/usfs_local_sids 
      chmod 755        /tmp/usfs_local_sids 
   fi
   if [[ ! -s /tmp/oraenv.usfs ]]; then
      cat >   /tmp/oraenv.usfs <<\EOF
#  FILE:
#  VERSION: 
#  DATE:  
#
#
# Purpose: Source this file to get an ORACLE_HOME by looking up ORACLE_SID in /etc/oratab
#          Sets ORACLE_HOME regardless of RAC or stand-alone, 10g or 11g
#          Calls the standard /usr/local/bin/oraenv
#
# Attention: Test any changes in bash, pdksh, and ksh93.
#
# Requires:
#   ORACLE_SID
#
# Results:
#   Sets envars based on ORACLE_SID:
#     ORACLE_HOME, PATH, LD_LIBRARY_PATH, etc.
#   Setting TNS_ADMIN and/or modifying PATH is left to the user

TAB=$(echo -e "\t")
# For bash, turn off shell history substitution for exclamation point
ps h -p $$ | grep -q bash && set +H

# Determine node/instance number for RAC nodes
INSTNBR=$( ps -ef | sed "/asm_pmon_+AS[M]/!d;s|.*asm_pmon_+AS[M]||" )
if [[ -z "$INSTNBR" ]]; then
   INSTNBR=$( sed "/^[ $TAB]*#/d; /^+ASM[0-9]:/!d; s|+ASM\([0-9]*\):.*|\1|" /etc/oratab )
fi

# Preserve current value of ORACLE_SID
orig_ORACLE_SID=$ORACLE_SID

# If this server is a RAC node, strip instance number
# from ORACLE_SID before calling oraenv
if [[ -n "$INSTNBR" ]]; then
   export ORACLE_SID=${ORACLE_SID%${INSTNBR}}
fi

orig_ORACLE_BASE=$ORACLE_BASE
# Call oraenv to set PATH, ORACLE_HOME,
#  LD_LIBRARY_PATH (for RDBMS servers), etc.
# Setting TNS_ADMIN and/or modifying PATH is left to the user
which dbhome 2> /dev/null || PATH=$PATH:/usr/local/bin/
ORAENV_ASK=NO
. /usr/local/bin/oraenv < /dev/null

# Restore original value of ORACLE_SID
export ORACLE_SID=$orig_ORACLE_SID

# If ORACLE_HOME was set to the ~oracle default, then oraenv failed;
#  try again with original value of ORACLE_SID as restored above
if [[ "$ORACLE_HOME" == ~oracle ]]; then
   . /usr/local/bin/oraenv
fi
ORACLE_BASE=$orig_ORACLE_BASE
EOF
      chown oracle.dba /tmp/oraenv.usfs
      chmod 755        /tmp/oraenv.usfs
   fi
   echo "$Script_name: .. Pass" | tee -a $VERBOSE
}
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#================================================================
#
### MAIN
#
#================================================================

export Script_name=$(basename $0)
set_envars
check_required_files
set_SIDS

echo " These are the Oracle SIDS to be checked " 
echo $SIDS

#  if Value is FALSE  then audit is not on. 
# Need to run the audit turn on script.  

   export SQLFILE1=/tmp/DG_DB0029a.sql
   cat > $SQLFILE1 <<\EOF
    select value from v$parameter where name = 'audit_sys_operations'

      l
      r
EOF
chmod 777 /tmp/DG_DB0029a.sql
#
#  if Value is FALSE  then audit is not on. 
# Need to run the audit turn on script.  
#
#
if [[ $1 != "-b" ]]; then
   for ORACLE_SID in $SIDS; do
      export ORACLE_SID
      echo "ORACLE_SID=$ORACLE_SID" 2>&1 | tee -a $VERBOSE
      echo "Oracle_SID=$ORACLE_SID"
      ORACLE_HOME=$(. /tmp/oraenv.usfs >/dev/null 2>/dev/null; \
         echo $ORACLE_HOME)
      echo ORACLE_HOME=$ORACLE_HOME >> $VERBOSE
      [[ ! -d $ORACLE_HOME ]] && echo "couldn't determine ORACLE_HOME for ORACLE_SID=$ORACLE_SID"
      (
            export ORACLE_SID=$ORACLE_SID;
            . /tmp/oraenv.usfs;
            PATH=$ORACLE_HOME/bin:$PATH;
            sqlplus "/ AS SYSDBA" < $SQLFILE1) \
         > $VERBOSE.$ORACLE_SID.log 2>&1
      echo "== $TESTNUM ==" >> $VERBOSE    
      cat $VERBOSE.$ORACLE_SID.log >> $VERBOSE
      grep ORA-[0-9][0-9][0-9][0-9][0-9] $VERBOSE.$ORACLE_SID.log \
         | grep -Ev '^ORA-00000|^ORA-01920' && \
         error_exit 5 "ERROR running test $TESTNUM"

      if grep -i ^TRUE $VERBOSE.$ORACLE_SID.log; then 
         echo " Is set to true " >> $VERBOSE  # Audit already turned on
      else 
         echo " Is set to False - Run the oracle_audit.11g.os.non_syslog.sh with $ORACLE_SID " >> $VERBOSE  # need to turn Audit on
         ksh oracle_audit.11g.os.non_syslog.sh -o $ORACLE_SID
      fi
   done
else
   for ORACLE_SID in $SIDS; do
      export ORACLE_SID
      ksh oracle_audit.11g.os.non_syslog.sh -o $ORACLE_SID -b
   done
fi

