#!/usr/bin/env ksh

set -A patterns "0" "%03d" "%03d%03d" "%03d%03d%03d" "%03d%03d%03d%03d" "%03d%03d%03d%03d%03d" "%03d%03d%03d%03d%03d%03d" \
"%03d%03d%03d%03d%03d%03d%03d" \
"%03d%03d%03d%03d%03d%03d%03d%03d" \
"%03d%03d%03d%03d%03d%03d%03d%03d%03d" \
"%03d%03d%03d%03d%03d%03d%03d%03d%03d%03d" \
"%03d%03d%03d%03d%03d%03d%03d%03d%03d%03d%03d"

export DEBUG=": "
export patterns
$DEBUG export patterns_max=${#patterns[@]}
echo patterns_max=$patterns_max
#cnt=0; while ((cnt<$cnt_max)); do echo "$cnt: ${patterns[$cnt]}"; ((cnt=cnt+1)); done

function func_comp_ver {
   # $1 Current component:version
   # $2 Expected minimum version
   component=$1
   expected_min_ver=$2
   nonpadded_revs=$(echo $(echo "$component" | tr '.-' '\n' | grep -v '[A-Za-z]' ) )
   $DEBUG echo "nonpadded_revs=$nonpadded_revs:"
   nonpadded_revs_cnt=$(echo "$nonpadded_revs" | wc -w)
   $DEBUG echo "nonpadded_revs_cnt=$nonpadded_revs_cnt"

   len_expected_min_ver=${#expected_min_ver}
   if ((len_expected_min_ver>nonpadded_revs_cnt*3)); then
      expected_min_ver=$(echo "$expected_min_ver" | cut -c1-$((nonpadded_revs_cnt*3)) )
      $DEBUG echo Trunc: expected_min_ver=$expected_min_ver
   fi
   len_expected_min_ver=${#expected_min_ver}
   $DEBUG echo printf ${patterns[$nonpadded_revs_cnt]}\n
   export padded_cur_ver=$(printf "${patterns[$nonpadded_revs_cnt]}\n" $nonpadded_revs)
   if ((len_expected_min_ver < nonpadded_revs_cnt*3)); then
      padded_cur_ver=$(echo "$padded_cur_ver" | cut -c1-$len_expected_min_ver)
      $DEBUG echo "Trunc: padded_cur_ver=$padded_cur_ver"
   fi
   $DEBUG echo "padded_cur_ver=$padded_cur_ver:"
   #echo $(echo redhat-lsb-3.1-12.3.EL.0.2 | tr '.-' '\n' | grep -v '[A-Za-z]' ) | wc -w
   $DEBUG echo "{#padded_cur_ver}=${#padded_cur_ver}  >=  {#expected_min_ver}=${#expected_min_ver}"
   $DEBUG echo "if (( $padded_cur_ver >= "
   $DEBUG echo "      $expected_min_ver )); then "
   if (( $padded_cur_ver >= $expected_min_ver )); then 
      echo "PASS: $component min=$expected_min_ver"
   else 
      echo "FAIL: $component min=$expected_min_ver" | tee -a /tmp/version_compare.sh.fail.log
   fi
}

# rpm -q compat-libstdc++-33 | sed 's|^\([^\.]*\)-[0-9][0-9]*\..*|\1|'
#i686 not specifically required pair="libgcc-*.i686|004004004013"
for pair in \
"binutils|002020051000002" \
"compat-libcap1|001010001" \
"compat-libstdc++-33-*.x86_64|033003002003069" \
"compat-libstdc++-33-*.i686|033003002003069" \
"gcc|004004004013" \
"gcc-c++|004004004013" \
"glibc-*.x86_64|002012001007" \
"glibc-*.i686|002012001007" \
"glibc-common|002012001007" \
"glibc-devel-*.x86_64|002012001007" \
"glibc-devel-*.i686|002012001007" \
"libaio-*.x86_64|000003107010" \
"libaio-*.i686|000003107010" \
"libaio-devel-*.x86_64|000003107010" \
"libgcc-*.x86_64|004004004013" \
"libgcc-*.i686|004004004013" \
"libstdc++-4*.x86_64|004004004013" \
"libstdc++-4*.i686|004004004013" \
"libstdc++-devel|004004004013" \
"libXext-1*.i686|001003001002" \
"libXtst-1*.i686|001002001002" \
"libXi-1*.i686|001006001003" \
"make|003081" \
"openmotif|002002003" \
"openmotif22-*.x86_64|002002003" \
"redhat-lsb-core-*.x86_64|004000007" \
"sysstat|009000004011" \
"xorg-x11-utils|000000000" \
"xorg-x11-apps|000000000" \
"xorg-x11-xinit|000000000" \
"xorg-x11-server-Xorg|000000000" \
"xterm|000000000" \
"elfutils-libelf-*.x86_64|000125" \
"elfutils-libelf-devel-*.x86_64|000125" \
"expect"
#"elfutils-libelf-*.i686|000125" \
#"elfutils-libelf-devel-*.i686|000125" \
#"nc-*.x86_64|000000" \
do
   name=${pair%%\|*}
   target_ver=${pair##*\|}
   rpm_comp=$(rpm -q $name 2> /dev/null | grep -v '^package [^ ]* is not installed$' | sort -u)
   if [[ -n "$rpm_comp" ]]; then
      $DEBUG echo rpm_comp=$rpm_comp
      cnt=$(echo $rpm_comp | wc -w)
      if ((cnt>1)); then echo "Too many '$name'.  See 'rpm -q $name | sort -u'"; 
      else func_comp_ver $rpm_comp $target_ver; fi
   else
      echo "No '$name' found."
   fi
   $DEBUG echo Pause; 
   $DEBUG read q
done



