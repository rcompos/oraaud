Install:  Run as user oracle:  install_ora_audit.sh
          Run as root:         config_oraaud_OS_service.sh

Create tar file   tar -cvpf /fslink/sysinfra/oracle/scripts/misc/auditing/rn-ora_audit_nitc.tar \
/home/oracle/system/audit/config_oraaud_OS_service.sh \
/home/oracle/system/audit/config_scp_ora_audit.sh \
/home/oracle/system/audit/install_ora_audit.sh \
/home/oracle/system/audit/install_srpt_audit.sh \
/home/oracle/system/audit/oracle_audit.11g.os.non_syslog.sh \
/home/oracle/system/audit/oracle_audit.removal.sles.sh \
/home/oracle/system/audit/oracle_turnon_audit.sh \
/home/oracle/system/audit/oraenv.usfs \
/home/oracle/system/audit/ReadMe.txt \
/home/oracle/system/audit/scp_audit.sh \
/home/oracle/system/audit/version_compare.sh
cksum /fslink/sysinfra/oracle/scripts/misc/auditing/rn-ora_audit_nitc.tar
