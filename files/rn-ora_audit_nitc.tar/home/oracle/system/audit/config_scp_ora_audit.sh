#!/usr/bin/env ksh
#
#  @(#)fs615/db/ora/src/system/config_scp_ora_audit.sh, ora, build5_3, build5_3g,1.2:1/25/10:09:47:32
#  VERSION:  2.1
#  DATE:  11/4/2015
#
#
#  US Government Users Restricted Rights
#
# Purpose: 
#   Create public keys for transfering Oracle audit records.

export Script_name=$(basename $0)
mkdir /home/oracle/system/audit/.audit 2>/dev/null
chown oracle.oinstall /home/oracle/system/audit/.audit
chmod 700 /home/oracle/system/audit/.audit
umask 002
export LOG=/home/oracle/system/audit/.audit/install_ora_audit.sh
touch $LOG
chown oracle.oinstall $LOG
chmod 700 $LOG

{
   function usage_exit {
      echo "$0 [-h]"
      echo "   -h help"
      exit 1
   }
   function func_whoami {
      echo "$Script_name== Who am I $(date)"
      if [ $(whoami) != oracle ]; then
         echo "Error: You must be user oracle to run this script."
         exit 1
      fi
   }
   function ECHO {
      echo "$(date "+%Y-%m-%d:%H:%M:%S")-$Script_name: \c" >> $LOG
      echo "$*" | tee -a $LOG
   }
   function func_set_envars {
      echo "$Script_name== Set envars $(date)"
      if [[ $(host $(hostname) ) == *fs.usda.gov* ]]; then
         export DEST_DIR=/app/home/nfadmin/allaud
         export SCP_USER=S_SIEM-OracleLogs
         export SCP_HOST=fsxopsx0024.edc.ds1.usda.gov
      elif [[ $(host $(hostname) ) == *mci.fs.fed.us* ]]; then
         export DEST_DIR=/nfx/home/nfadmin/allaud
         export SCP_USER=svc_nfxscplogs
         export SCP_HOST=slornetf2
      else
         export DEST_DIR=/nfx/home/nfadmin/allaud
         export SCP_USER=svc_nfxscplogs
         export SCP_HOST=slornetf
      fi
      ping -c 2 $SCP_HOST # Don't use the "tee" command, or $? is erroroneous
      rc=$?
      if [[ $rc != 0 ]]; then 
         ECHO "ERROR: couldn't ping $SCP_HOST."
      exit $rc
      fi
   }
   function func_mkdir_dot_ssh {
      echo "$Script_name== Make ~/.ssh $(date)"
      if [[ ! -d $HOME/.ssh ]]; then
         ECHO "Making $HOME/.ssh"
         mkdir $HOME/.ssh 2>&1 | tee -a $LOG
         chmod 2700 $HOME/.ssh 2>&1 | tee -a $LOG
      fi
   }
   function func_ssh_keygen_public_key {
      echo "$Script_name== keygen public key $(date)"
      if [[ ! -f $HOME/.ssh/id_dsa.pub ]]; then
         ECHO "Please press the Enter key for the following password prompts"
         ECHO "Please wait 30 seconds for the DSA key generator to start"
         /usr/bin/ssh-keygen -t dsa -N "" -f $HOME/.ssh/id_dsa 2>&1 | tee -a $LOG
         if [[ ! -f $HOME/.ssh/id_dsa.pub ]]; then
            ECHO "ERORR: $HOME/.ssh/id_dsa.pub is missing.  Script exiting"
            exit 1
         fi
      fi
      cp $HOME/.ssh/id_dsa.pub  $HOME/.ssh/id_dsa.pub.$(host $(hostname) | sed 's| .*||')
   }
   function func_prompt_remote_password {
      echo "$Script_name== Prompt remote password $(date)"
      if [[ -z $SCP_PW ]]; then
         while true; do
            echo "Enter the password for $SCP_USER at $SCP_HOST: "
            stty -echo
            read SCP_PW_try1
            echo "Confirm password: "
            read SCP_PW
            stty echo
            [[ $SCP_PW_try1 == $SCP_PW ]] && break
            echo "Passowrds don't match"
         done
      fi
      export SCP_PW
   }
   ##############################################################################
   # Sub Routines of func_tranfer_public_key
   ##############################################################################
         function sub_expect_mkdir_home_ssh {
            echo "$Script_name== Expect make directory .ssh remotely $(date)"
            #!/usr/bin/expect -f
            cat > expect_mkdir_ssh.sh <<EOF
#!/usr/bin/expect
            spawn ssh -q -n $SCP_USER@$SCP_HOST mkdir ~/.ssh
            expect {
               -re ".*es.*o.*" {
                  exp_send "yes\r"
                  exp_continue
               }
               -re ".*sword.*" {
                  send "\$env(SCP_PW)\\r"
               }
            }
            interact
EOF
            chmod 700 expect_mkdir_ssh.sh
            ./expect_mkdir_ssh.sh 2>& 1 | tee -a $LOG > ./expect_mkdir_ssh.sh.log
            if ! grep 'File already exits' ./expect_mkdir_ssh.sh.log; then
               rc=$?
               echo rc=$rc
               if [[ $rc != 0 ]]; then
                  ECHO "ERROR: could create ~/.ssh on $SCP_HOST."
                  exit $rc
               fi
            fi
         }
         function sub_expect_id_dsa_pub_hostname {
            echo "$Script_name== Expect transfer public key $(date)"
            export SCP_ID_DSA_PUB=id_dsa.pub.$(host $(hostname)|sed 's| .*||')
            cat > expect_scp_id_dsa_pub.sh <<EOF
#!/usr/bin/expect
               spawn scp -q $HOME/.ssh/id_dsa.pub $SCP_USER@$SCP_HOST:~/.ssh/$SCP_ID_DSA_PUB
               expect {
                  -re ".*es.*o.*" {
                     exp_send "yes\r"
                     exp_continue
                  }
                  -re ".*sword.*" {
                     exp_send "\$env(SCP_PW)\\r"
                  }
               }
               interact
EOF
            chmod 700 expect_scp_id_dsa_pub.sh
            ./expect_scp_id_dsa_pub.sh 2>&1 | tee -a $LOG >> ./expect_scp_id_dsa_pub.sh.log
            rc=$?
            echo rc=$rc >> $LOG
            cnt1=0$(grep -n '    while executing' < ./expect_scp_id_dsa_pub.sh.log | sed 's|:.*||' | head -1)
            cnt2=0$(grep -n '"interact"' ./expect_scp_id_dsa_pub.sh.log | sed 's|:.*||' | head -1)
            echo "cnt1=$cnt1"
            echo "cnt2=$cnt2"
            if (( (cnt2>0) && (cnt2!=cnt1+1) )); then
               echo rc=$rc
               if [[ $rc != 0 ]]; then
                  ECHO "ERROR: could create authorized_keys from id_ds.pub on $SCP_HOST."
                  exit $rc
               fi
            fi
            echo ".. pass"
         }
         function sub_expect_cat_all_id_dsa_pub {
            echo "$Script_name== Expect cat all public keys $(date)"
            cat > expect_cat_public_keys.sh <<EOF
#!/usr/bin/expect
            #orig spawn ssh -q -n $SCP_USER@$SCP_HOST cat ~/.ssh/id_dsa.pub.* > ~/.ssh/authorized_keys\; chmod 600 ~/.ssh/authorized_keys\; ls -l ~/.ssh/authorized_keys
            spawn ssh -q $SCP_USER@$SCP_HOST cat ~/.ssh/id_dsa.pub.* > ~/.ssh/authorized_keys\; chmod 600 ~/.ssh/authorized_keys\; ls -l ~/.ssh/authorized_keys
            expect {
               -re ".*es.*o.*" {
                  exp_send "yes\r"
                  exp_continue
               }
               -re ".*sword.*" {
                 send "\$env(SCP_PW)\\r"
               }
            }
            interact
EOF
            chmod 700 expect_cat_public_keys.sh
            ./expect_cat_public_keys.sh 2>&1 | tee -a $LOG > ./expect_cat_public_keys.sh.log
            if ! grep -- '-rw------- .*/.ssh/authorized_keys' ./expect_cat_public_keys.sh.log >> $LOG; then
               ECHO "ERROR: could create authorized_keys from id_ds.pub on $SCP_HOST."
               exit 3
            fi
            echo ".. pass"
         }
         function sub_remote_create_cat_id_dsa_pub_sh {
            echo "$Script_name== Create remote cat_id_dsa_pub.sh $(date)"
            ssh -q -n  $SCP_USER@$SCP_HOST 'ls ~/.ssh/cat_id_dsa_pub.sh' 2>&1 | tee -a $LOG > ssh_ls_cat_id_dsa_pub.sh.log
            rc=$?
            echo rc=$rc
            cat ssh_ls_cat_id_dsa_pub.sh.log >> $LOG
            if [[ $rc != 0 ]]; then
              ssh -q $SCP_USER@$SCP_HOST 'echo "while true; do cat ~/.ssh/id_dsa.pub.* > ~/.ssh/authorized_keys; chmod 600 ~/.ssh/authorized_keys; sleep 60; done" > ~/.ssh/cat_id_dsa_pub.sh; chmod 600 ~/.ssh/cat_id_dsa_pub.sh'
            fi
            echo ".. pass"
         }
         function sub_nohup_remote_cat_id_dsa_pub_sh {
            echo "$Script_name== Nohup remote cat_id_dsa_pub.sh $(date)"
            ssh -q $SCP_USER@$SCP_HOST 'ps -ef' 2>&1 | grep '/bin/bash .*/.ssh/cat_id_dsa_pub.sh' >> $LOG
            rc=$?
            echo rc=$rc
            if [[ $rc != 0 ]]; then  # Try to start the script
               #(ssh -qn  $SCP_USER@$SCP_HOST 'nohup /bin/bash ~/.ssh/cat_id_dsa_pub.sh &' & >> $LOG 2>&1); sleep 2; echo  
               (ssh -qn  $SCP_USER@$SCP_HOST 'nohup /bin/bash ~/.ssh/cat_id_dsa_pub.sh &' &) >> $LOG 2>&1; sleep 2; echo  
            fi
            echo ".. pass"
         }
         
   function func_tranfer_public_key {
      echo "$Script_name== Transfer public key $(date)"
      if [[ -d /fslink/sysinfra/home/$SCP_USER ]]; then
         cp $HOME/.ssh/id_dsa.pub /fslink/sysinfra/home/$SCP_USER/.ssh/id_dsa.pub.$(host $(hostname) | sed 's| .*||') 
         cat /fslink/sysinfra/home/$SCP_USER/.ssh/id_dsa.pub.* > /fslink/sysinfra/home/$SCP_USER/.ssh/authorized_keys

         chmod 700 /fslink/sysinfra/home/$SCP_USER/.ssh
         chmod 700 /fslink/sysinfra/home/$SCP_USER/.ssh/authorized_keys
         chmod go-w /fslink/sysinfra/home/$SCP_USER
      else
         ECHO "Enter 'yes' when prompted to continue"
         ECHO "Enter the password to '$SCP_USER@$SCP_HOST' when prompted"
         ECHO ""
         ECHO ""

         sub_expect_mkdir_home_ssh

         sub_expect_id_dsa_pub_hostname

         sub_expect_cat_all_id_dsa_pub

         sub_remote_create_cat_id_dsa_pub_sh

         sub_nohup_remote_cat_id_dsa_pub_sh
      fi
   }
   function remote_ssh_backout {
      echo "$Script_name== Backout remote ssh keys $(date)"
      export SCP_ID_DSA_PUB=id_dsa.pub.$(host $(hostname)|sed 's| .*||')
      #!/usr/bin/expect -f
      cat > expect_mkdir_ssh.sh <<EOF
#!/usr/bin/expect
         spawn ssh -q -n $SCP_USER@$SCP_HOST rm ~/.ssh/$SCP_ID_DSA_PUB
         expect {
            -re ".*es.*o.*" {
               exp_send "yes\r"
               exp_continue
            }
            -re ".*sword.*" {
               send "\$env(SCP_PW)\\r"
            }
         }
         interact
EOF
      chmod 700 expect_mkdir_ssh.sh
      ./expect_mkdir_ssh.sh > ./expect_mkdir_ssh.sh.log 2>&1
      if ! grep 'File already exits' ./expect_mkdir_ssh.sh.log; then
         rc=$?
         echo rc=$rc
         if [[ $rc != 0 ]]; then
            ECHO "ERROR: could create ~/.ssh on $SCP_HOST."
            exit $rc
         fi
      fi
   }
   ###########################################################################
   # Main
   func_whoami
   while getopts hbo: option
   do
      case "$option"
      in
         h) usage_exit 1;;
         o) export ORACLE_SID="$OPTARG";;
         b) export BACKOUT_FLAG="TRUE";;
        \?)
            eval print -- "ERROR:" '$'$( echo $OPTIND - 1 | bs ) \
                          "option is not a supported switch."
            usage_exit 1;;
      esac
   done
   func_set_envars
   if [[ -z $BACKOUT_FLAG ]]; then
      func_mkdir_dot_ssh
      func_ssh_keygen_public_key
      func_prompt_remote_password
      func_tranfer_public_key
   else
      remote_ssh_backout
   fi
} 2>&1 | tee -a $LOG

echo "$Script_name: SCRIPT SUCCESSFULLY COMPLETED, $(date), log file is $LOG " | tee -a $LOG
