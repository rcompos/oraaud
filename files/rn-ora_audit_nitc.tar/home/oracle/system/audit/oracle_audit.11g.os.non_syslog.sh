#!/usr/bin/env ksh
#
#  @(#)fs615/db/ora/src/system/oracle_audit.10g.os.non_syslog.sh, ora, build5_3, build5_3g,1.1:4/3/10:07:54:07
#  VERSION:  2.0
#  DATE:  10/2/12
#
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted
#
# Purpose:
#    Audit users with DBA and also DBA priviledges
#
# Requires:  ORACLE_SID be set
#            User must run as AIX user oracle
#
# WARNING: User is required to review for errors.

export Script_name=$(basename $0)
mkdir /home/oracle/system/audit/.audit 2>/dev/null
chown oracle.oinstall /home/oracle/system/audit/.audit
chmod 700 /home/oracle/system/audit/.audit
umask 002
export LOG=/home/oracle/system/audit/.audit/install_ora_audit.sh
touch $LOG
chown oracle.oinstall $LOG
chmod 700 $LOG

{
   function error_exit {
      echo "  ERROR $2" | tee -a $LOG
      exit $1
   }
   function set_log_envars {
      echo "$Script_name==Setting initial envars $(date)"
      $DEBUG
      mkdir /home/oracle/system/audit/.audit 2>/dev/null
      chown oracle.dba /home/oracle/system/audit/.audit
      chmod 700 /home/oracle/system/audit/.audit
      umask 002 
      #export LOG=/home/oracle/system/audit/.audit/oracle_audit.11g.os.non_syslog.sh.log
      touch $LOG
      chown oracle.dba $LOG
      chmod 777 $LOG
      export SQL1=/home/oracle/system/audit/.audit/ora_audit.1.sql
      export SQL2=/home/oracle/system/audit/.audit/ora_audit.2.sql
      export TS=$(date "+%Y-%m-%d:%H:%M:%S")
      export SHUTDOWN_REQUIRED=NO
      # Removal envars
      export RM_SQL1=/home/oracle/system/audit/.audit/noaudit_stmt.sql
      export RM_LST1_1=/home/oracle/system/audit/.audit/noaudit_stmt.1_1.lst
      export RM_LST1_2=/home/oracle/system/audit/.audit/noaudit_stmt.1_2.lst
      export RM_SQL2=/home/oracle/system/audit/.audit/show_parameter_audit.sql
      export RM_LST2=/home/oracle/system/audit/.audit/show_parameter_audit.lst
   }
   function usage_exit {
      echo "Usage:"
      echo "./oracle_audit.10g.os.non_syslog.sh -o <oracle_sid>"
      echo '$ORA_VER can be preset'
      exit 1
   }
   function func_check_user {
      echo "$Script_name== Check user =="
      $DEBUG
      [[ $(whoami) == oracle ]] || error_exit 1 "ERROR: run as oracle"
   }
   function check_db_running {
      echo "$Script_name== Check for DB running =="
      echo "ORACLE_SID=$ORACLE_SID" >> $LOG
      $DEBUG
      [[ -z $ORACLE_SID ]] && error_exit 2 "use '-o <sid>' for database SID"
      if ! ps -ef | grep [o]ra_pmon_${ORACLE_SID}$ >> $LOG; then
         error_exit 3 "ERROR: SID '$ORACLE_SID' is not currently running"
      fi
   }
   function func_check_required_files {
      echo "$Script_name== Check for required files"
      echo "ORACLE_SID=$ORACLE_SID" >> $LOG
      $DEBUG
      if [[ ! -s /tmp/oraenv.usfs ]]; then
         cat >   /tmp/oraenv.usfs <<\EOF
#  FILE:
#  VERSION:
#  DATE:
#
#
# Purpose: Source this file to get an ORACLE_HOME by looking up ORACLE_SID in /etc/oratab
#          Sets ORACLE_HOME regardless of RAC or stand-alone, 10g or 11g
#          Calls the standard /usr/local/bin/oraenv
#
# Attention: Test any changes in bash, pdksh, and ksh93.
#
# Requires:
#   ORACLE_SID
#
# Results:
#   Sets envars based on ORACLE_SID:
#     ORACLE_HOME, PATH, LD_LIBRARY_PATH, etc.
#   Setting TNS_ADMIN and/or modifying PATH is left to the user

TAB=$(echo -e "\t")
# For bash, turn off shell history substitution for exclamation point
ps h -p $$ | grep -q bash && set +H

# Determine node/instance number for RAC nodes
INSTNBR=$( ps -ef | sed "/asm_pmon_+AS[M]/!d;s|.*asm_pmon_+AS[M]||" )
if [[ -z "$INSTNBR" ]]; then
   INSTNBR=$( sed "/^[ $TAB]*#/d; /^+ASM[0-9]:/!d; s|+ASM\([0-9]*\):.*|\1|" /etc/oratab )
fi

# Preserve current value of ORACLE_SID
orig_ORACLE_SID=$ORACLE_SID

# If this server is a RAC node, strip instance number
# from ORACLE_SID before calling oraenv
if [[ -n "$INSTNBR" ]]; then
   export ORACLE_SID=${ORACLE_SID%${INSTNBR}}
fi

orig_ORACLE_BASE=$ORACLE_BASE
# Call oraenv to set PATH, ORACLE_HOME,
#  LD_LIBRARY_PATH (for RDBMS servers), etc.
# Setting TNS_ADMIN and/or modifying PATH is left to the user
which dbhome 2> /dev/null || PATH=$PATH:/usr/local/bin/
ORAENV_ASK=NO
. /usr/local/bin/oraenv < /dev/null

# Restore original value of ORACLE_SID
export ORACLE_SID=$orig_ORACLE_SID

# If ORACLE_HOME was set to the ~oracle default, then oraenv failed;
#  try again with original value of ORACLE_SID as restored above
if [[ "$ORACLE_HOME" == ~oracle ]]; then
   . /usr/local/bin/oraenv
fi
ORACLE_BASE=$orig_ORACLE_BASE
EOF
         chown oracle.dba /tmp/oraenv.usfs
         chmod 777        /tmp/oraenv.usfs
      fi
   }
   function func_set_OH {
      echo "$Script_name== Set OH"
      $DEBUG
      OH=$( (
         export ORACLE_SID=$ORACLE_SID;
         . /tmp/oraenv.usfs;
         echo ORACLE_HOME=$ORACLE_HOME) | sed '/^ORACLE_HOME/!d; s/ORACLE_HOME=//')
      echo "OH=$OH" >> $LOG
      [[ -d $OH ]] || error_exit 2 "could not determine ORACLE_HOME for ORACLE_SID=$ORACLE_SID"
   }
   function func_query_init_ora_parms {
      echo "$Script_name== Query Init parms"
      echo "ORACLE_SID=$ORACLE_SID" >> $LOG
      $DEBUG
      cat > /home/oracle/system/audit/.audit/query_audit_trail.sql <<\EOF
         select 'audit_trail=' || value from v$parameter where name='audit_trail' 

         l
         r
         select 'audit_sys_operations=' || value from v$parameter where name='audit_sys_operations' 

         l
         r
         select 'SPFILE=' || value from v$parameter where name='spfile' and value is not null

         l
         r
         exit;
EOF
      chmod 777 /home/oracle/system/audit/.audit/query_audit_trail.sql
      (
         export ORACLE_SID=$ORACLE_SID;
         . /tmp/oraenv.usfs;
         PATH=$ORACLE_HOME/bin:$PATH;
         sqlplus "/ AS SYSDBA" @/home/oracle/system/audit/.audit/query_audit_trail.sql;
         ) 2>&1 | tee -a $LOG > $LOG.$ORACLE_SID.query_init_ora_parms.lst 2>&1
      if grep ORA- $LOG.$ORACLE_SID.query_init_ora_parms.lst; then
         error_exit 3 "ERROR: couldn't query audit_trail"
      fi
      export cur_audit_trail=$(sed '/^audit_trail=/!d; s|.*=||' $LOG.$ORACLE_SID.query_init_ora_parms.lst)
      echo "cur_audit_trail=$cur_audit_trail" >> $LOG
      export cur_audit_sys_operations=$(
         sed '/^audit_sys_operations=/!d; s|.*=||' $LOG.$ORACLE_SID.query_init_ora_parms.lst)
      echo "cur_audit_sys_operations=$cur_audit_sys_operations" >> $LOG
      cur_SPFILE=$(
         sed '/^SPFILE=/!d; s|.*=||' $LOG.$ORACLE_SID.query_init_ora_parms.lst)
      echo "cur_SPFILE=$cur_SPFILE" >> $LOG
      if [[ $ORA_VER != 10.2.* ]]; then
         if [[ -z $cur_SPFILE ]]; then
            error_exit 4 "database does not use an spfile."
         fi
      fi
   }
   function func_sw_version {
      echo "$Script_name== Query software version"
      echo "ORACLE_SID=$ORACLE_SID" >> $LOG
      $DEBUG
      cat > /home/oracle/system/audit/.audit/query_sw_version.sql <<\EOF
         select * from v$version

         l
         r
         exit
EOF
      chmod 777 /home/oracle/system/audit/.audit/query_sw_version.sql
      (
         export ORACLE_SID=$ORACLE_SID;
         . /tmp/oraenv.usfs;
         PATH=$ORACLE_HOME/bin:$PATH;
         sqlplus "/ AS SYSDBA" @/home/oracle/system/audit/.audit/query_sw_version.sql;
         ) 2>&1 | tee -a $LOG > $LOG.$ORACLE_SID.func_sw_version.lst 2>&1
      if grep ORA- $LOG.$ORACLE_SID.func_sw_version.lst; then
         error_exit 5 "couldn't query version"
      fi
      if [[ -z $ORA_VER ]]; then
         export ORA_VER=$(grep '^Oracle Database' $LOG.$ORACLE_SID.func_sw_version.lst | tr ' ' '\n' | grep '[0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*' | tail -1)
      fi
      echo "ORA_VER=$ORA_VER" >> $LOG
   }
   function func_set_audit_trail {
      # Input: $cur_audit_trail
      #        $cmd_audit_trail
      # Output: $SHUTDOWN_REQUIRED
      #
      echo "$Script_name== Set init parameter audit_trail"
      echo "ORACLE_SID=$ORACLE_SID" >> $LOG
      $DEBUG
      echo "cmd_audit_trail=$cmd_audit_trail||cur_audit_trail=$cur_audit_trail" >> $LOG
      if [[ $cmd_audit_trail != $cur_audit_trail ]]; then
         file=$OH/dbs/init${ORACLE_SID}.ora
         wc_init_ora=$(wc -l < $file)
         if ((wc_init_ora > 5)); then
            [[ -f $file.$TS ]] || cp -p $file $file.$TS >> $LOG 2>&1
            cp -p $file $file.work >> $LOG 2>&1
            grep -Ev "^audit_trail|^audit_syslog_level" $file.work > $file
            if [[ $cmd == 'audit' ]]; then
               echo "audit_trail=os" >> $file
            fi
            export SHUTDOWN_REQUIRED=YES
         else
            cat > /home/oracle/system/audit/.audit/set_audit_trail.sql <<EOF
               alter system set audit_trail=$cmd_audit_trail scope=spfile

               l
               r
               exit
EOF
            chmod 777 /home/oracle/system/audit/.audit/set_audit_trail.sql
            (
               export ORACLE_SID=$ORACLE_SID;
               . /tmp/oraenv.usfs;
               PATH=$ORACLE_HOME/bin:$PATH;
               sqlplus "/ AS SYSDBA" @/home/oracle/system/audit/.audit/set_audit_trail.sql;
               ) 2>&1 | tee -a $LOG > $LOG.$ORACLE_SID.set_audit_trail.lst 2>&1
            if grep ORA- $LOG.$ORACLE_SID.set_audit_trail.lst; then
               error_exit 6 "couldn't set audit_trail"
            fi
            export SHUTDOWN_REQUIRED=YES
         fi
      else
         echo "Audit_trail already set correctly"
      fi
      echo "SHUTDOWN_REQUIRED=$SHUTDOWN_REQUIRED" >> $LOG
   }
   function func_audit_sys_operations {
      # Input: $cur_audit_sys_operations
      #        $cmd_audit_sys_operations
      # Output: $SHUTDOWN_REQUIRED
      #
      echo "$Script_name== Set init pararameter audit_sys_operations"
      echo "ORACLE_SID=$ORACLE_SID" >> $LOG
      $DEBUG
      echo "cmd_audit_sys_operations=$cmd_audit_sys_operations||cur_audit_sys_operations=$cur_audit_sys_operations" >> $LOG
      if [[ $cmd_audit_sys_operations != $cur_audit_sys_operations ]]; then
         file=$OH/dbs/init${ORACLE_SID}.ora
         wc_init_ora=$(wc -l < $file)
         if ((wc_init_ora > 5)); then
            [[ -f $file.$TS ]] || cp -p $file $file.$TS >> $LOG 2>&1
            cp -p $file $file.work >> $LOG 2>&1
            grep -Ev "^audit_sys_operations|^audit_syslog_level" $file.work > $file
            if [[ $cmd == 'audit' ]]; then
               # Don't do this for 8i, but do it for 9i and up
               #echo "audit_sys_operations=true" >> $file
               # Enable audit_sys_operations in Oracle 10.2.0.4, do to bug 5634026
               echo "audit_sys_operations=true" >> $file
            fi
            export SHUTDOWN_REQUIRED=YES
         else
            cat > /home/oracle/system/audit/.audit/set_audit_sys_operations.sql <<EOF
               alter system set audit_sys_operations=$cmd_audit_sys_operations scope=spfile

               l
               r
               exit
EOF
            chmod 777 /home/oracle/system/audit/.audit/set_audit_sys_operations.sql
            (
               export ORACLE_SID=$ORACLE_SID;
               . /tmp/oraenv.usfs;
               PATH=$ORACLE_HOME/bin:$PATH;
               sqlplus "/ AS SYSDBA" @/home/oracle/system/audit/.audit/set_audit_sys_operations.sql;
               ) 2>&1 | tee -a $LOG > $LOG.$ORACLE_SID.set_audit_sys_operations.lst 2>&1
            if grep ORA- $LOG.$ORACLE_SID.set_audit_sys_operations.lst; then
               error_exit 7 "couldn't set audit_sys_operations"
            fi
         fi
      else
         echo "Audit_trail already set correctly"
      fi
      echo "SHUTDOWN_REQUIRED=$SHUTDOWN_REQUIRED" >> $LOG
   }
   function removal_create_sql_scripts {
      echo "$Script_name== Create sql scripts =="
      echo "ORACLE_SID=$ORACLE_SID" >> $LOG
      $DEBUG
      cat > $RM_SQL1 <<EOF
         set head off
         set feed off
         set sqlprompt '-- '
         spool $RM_LST1_1
            --select 'NOAUDIT '||privilege||';' from DBA_SYS_PRIVS WHERE GRANTEE='DBA';
            --select 'NOAUDIT ALL BY '||grantee||';' from dba_role_privs where 
            --    granted_role='DBA' and grantee <> 'SYS';
         
         select 'noaudit ' || AUDIT_OPTION || ';' from DBA_STMT_AUDIT_OPTS 
          where user_name is null;
         
            --select 'noaudit ' || AUDIT_OPTION || ' by ' || user_name || ';' from DBA_STMT_AUDIT_OPTS 
            --    where user_name is not null;
         spool off
         set feed on
         set head on
         set echo on
         set sqlprompt 'SQL> '
         spool $RM_LST1_2
         alter system reset audit_trail          scope=spfile sid='*';
         alter system reset audit_sys_operations scope=spfile sid='*';
         alter system reset audit_syslog_level   scope=spfile sid='*';
         @$RM_LST1_1
         select 'SELECT_COUNT_DBA_STMT_AUDIT_OPTS='||count(*) from DBA_STMT_AUDIT_OPTS;
         spool off
         exit
EOF
      chmod 777 $RM_SQL1 
      cat > $RM_SQL2 <<EOF
         spool $RM_LST2.$ORACLE_SID
         show parameter audit
         spool off
         exit
EOF
      chmod 777 $RM_SQL2 
   }
   function removal_noaudit_stmt {
      echo "$Script_name== Execute sqlplus"
      echo "ORACLE_SID=$ORACLE_SID" >> $LOG
      $DEBUG
      (
         export ORACLE_SID=$ORACLE_SID;
         . /tmp/oraenv.usfs;
         PATH=$ORACLE_HOME/bin:$PATH;
         sqlplus "/ AS SYSDBA" @$RM_SQL1;
         ) 2>&1 | tee -a $LOG > $LOG.$ORACLE_SID.noaudit_stmt.lst 2>&1
      if ! grep SELECT_COUNT_DBA_STMT_AUDIT_OPTS=0 $LOG.$ORACLE_SID.noaudit_stmt.lst >> $LOG 2>&1;
      then
         error_exit 1 "some privileges not revoked. 
            Please do these commands for a list of existing audited priviledges
               sqlplus / as sysdba
                  select * from DBA_STMT_AUDIT_OPTS;"
      fi
   }
   function func_create_sql_scripts {
      echo "$Script_name== Create sql script for enabling auditing"
      $DEBUG
      if [[ $ORA_VER == 10.2.* ]]; then
         cat > /home/oracle/system/audit/.audit/ora_audit.sql <<EOF
set head off
set feed off
set sqlprompt '-- '
spool /home/oracle/system/audit/.audit/start_auditing.sql
select 'alter system set audit_trail=$cmd_audit_trail scope=spfile;' 
      from v\$parameter where name='spfile' and value is not null;
select 'alter system set audit_sys_operations=$cmd_audit_sys_operations 
      scope=spfile;' from v\$parameter where name='spfile' and value is not null;

spool off
set feed on
set head on
set echo on
set sqlprompt 'SQL> '
$cmd all $cmd_by_access;

l
r
$cmd all privileges $cmd_by_access;

l
r
$cmd alter java class $cmd_by_access;

l
r
$cmd alter java resource $cmd_by_access;

l
r
$cmd alter java source $cmd_by_access;

l
r
$cmd alter sequence $cmd_by_access;

l
r
$cmd alter table $cmd_by_access;

l
r
$cmd comment table $cmd_by_access;

l
r
$cmd create java class $cmd_by_access;

l
r
$cmd create java resource $cmd_by_access;

l
r
$cmd create java source $cmd_by_access;

l
r
$cmd debug procedure $cmd_by_access;

l
r
$cmd drop java class $cmd_by_access;

l
r
$cmd drop java resource $cmd_by_access;

l
r
$cmd drop java source $cmd_by_access;

l
r
$cmd exempt access policy $cmd_by_access;

l
r
$cmd exempt identity policy $cmd_by_access;

l
r
$cmd grant directory $cmd_by_access;

l
r
$cmd grant procedure $cmd_by_access;

l
r
$cmd grant sequence $cmd_by_access;

l
r
$cmd grant table $cmd_by_access;

l
r
$cmd grant type $cmd_by_access;

l
r
$cmd sysdba $cmd_by_access;

l
r
$cmd sysoper $cmd_by_access;

l
r

spool /home/oracle/system/audit/.audit/audit_errors.lst
@/home/oracle/system/audit/.audit/start_auditing.sql
begin
    dbms_scheduler.drop_job('USFS_DELETE_SYS_AUD');
    end;
/
show parameter spfile
show parameter audit
spool off
exit
EOF
chmod 777 /home/oracle/system/audit/.audit/ora_audit.sql
else
      cat > /home/oracle/system/audit/.audit/ora_audit.sql <<EOF
set head off
set feed off
set sqlprompt '-- '
spool /home/oracle/system/audit/.audit/start_auditing.sql
select 'alter system set audit_trail=$cmd_audit_trail scope=spfile;' 
      from v\$parameter where name='spfile' and value is not null;
select 'alter system set audit_sys_operations=$cmd_audit_sys_operations 
      scope=spfile;' from v\$parameter where name='spfile' and value is not null;

spool off
set feed on
set head on
set echo on
set sqlprompt 'SQL> '
$cmd all $cmd_by_access

l
r
$cmd all privileges $cmd_by_access;

l
r
$cmd alter database link $cmd_by_access;

l
r
$cmd alter java class $cmd_by_access;

l
r
$cmd alter java resource $cmd_by_access;

l
r
$cmd alter java source $cmd_by_access;

l
r
$cmd alter mining model $cmd_by_access;

l
r
$cmd alter public database link $cmd_by_access;

l
r
$cmd alter sequence $cmd_by_access;

l
r
$cmd alter table $cmd_by_access;

l
r
$cmd comment edition $cmd_by_access;

l
r
$cmd comment mining model $cmd_by_access;

l
r
$cmd comment table $cmd_by_access;

l
r
$cmd create java class $cmd_by_access;

l
r
$cmd create java resource $cmd_by_access;

l
r
$cmd create java source $cmd_by_access;

l
r
$cmd debug procedure $cmd_by_access;

l
r
$cmd drop java class $cmd_by_access;

l
r
$cmd drop java resource $cmd_by_access;

l
r
$cmd drop java source $cmd_by_access;

l
r
$cmd execute assembly;

l
r
$cmd exempt access policy $cmd_by_access;

l
r
$cmd exempt identity policy $cmd_by_access;

l
r
$cmd grant directory $cmd_by_access;

l
r
$cmd grant edition $cmd_by_access;

l
r
$cmd grant mining model $cmd_by_access;

l
r
$cmd grant procedure $cmd_by_access;

l
r
$cmd grant sequence $cmd_by_access;

l
r
$cmd grant table $cmd_by_access;

l
r
$cmd grant type $cmd_by_access;

l
r
$cmd sysdba $cmd_by_access;

l
r
$cmd sysoper $cmd_by_access;

l
r

spool /home/oracle/system/audit/.audit/audit_errors.lst
@/home/oracle/system/audit/.audit/start_auditing.sql
begin
    dbms_scheduler.drop_job('USFS_DELETE_SYS_AUD');
    end;
/
show parameter spfile
show parameter audit
spool off
exit
EOF
         chmod 777 /home/oracle/system/audit/.audit/ora_audit.sql
      fi
   }
   function func_run_sqlplus {
      echo "$Script_name== Run SQL*Plus"
      $DEBUG
      (
        $DEBUG
         export ORACLE_SID=$ORACLE_SID;
         . /tmp/oraenv.usfs;
         PATH=$ORACLE_HOME/bin:$PATH;
         sqlplus "/ AS SYSDBA" @/home/oracle/system/audit/.audit/ora_audit.sql;
         ) 2>&1 | tee -a $LOG > $LOG.$ORACLE_SID.func_run_sqlplus.lst 2>&1
      if grep -Ev 'ORA-06512|ORA-27475: "SYS.USFS_DELETE_SYS_AUD" must be a job' /home/oracle/system/audit/.audit/start_auditing.sql /home/oracle/system/audit/.audit/audit_errors.lst $LOG.$ORACLE_SID.func_run_sqlplus.lst | grep ORA-; then  
         error_exit 8 "found ORA-xxxxx error(s)"
      fi
   }
   function func_cycle_database {
      echo "$Script_name== Conditionally cycle database =="
      $DEBUG
      echo "SHUTDOWN_REQUIRED=$SHUTDOWN_REQUIRED" >> $LOG
      echo "BYPASS_STOP=$BYPASS_STOP" >> $LOG
      if [[ $BYPASS_STOP != "YES" && $SHUTDOWN_REQUIRED == "YES" ]]; then
         INSTNBR=$( ps -ef | sed "/asm_pmon_+AS[M]/!d;s|.*asm_pmon_+AS[M]||" )
         if [[ -z "$INSTNBR" ]]; then
            INSTNBR=$( sed "/^[ $TAB]*#/d; /^+ASM[0-9]:/!d; s|+ASM\([0-9]*\):.*|\1|" /etc/oratab )
         fi
         if [[ -n "$INSTNBR" ]]; then
            # This server is a RAC node
            # It is an error if a dbname ends with a numeral in oratab
            DB_NAME=$(echo $ORACLE_SID | sed "s|$INSTNBR$||")
         else
            # This server is a Stand-Alone server
            DB_NAME=$ORACLE_SID
         fi
         echo "srvctl stop database -d $DB_NAME 2>&1" >> $LOG
         srvctl stop database -d $DB_NAME 2>&1
         # Start database
         echo "srvctl start database -d $DB_NAME 2>&1" >> $LOG
         srvctl start database -d $DB_NAME 2>&1
      fi
   }
   #==============================================================================
   #Main
   set_log_envars
   echo "$(date) START oracle_audit.10g.os.non_syslog.sh" >> $LOG
   # Set command envars
      export cmd='audit'
      export cmd_by_access='by access'
      export cmd_audit_trail='OS'
      # Enable audit_sys_operations in Oracle 10.2.0.4, do to bug 5634026
      export cmd_audit_sys_operations='TRUE'
      # . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
      # This code doesn't export the envars properly when in a function
      echo "$Script_name== Getopts =="
      unset ORACLE_SID
      while getopts sbo:h option; do
         echo " Option = $option  $OPTARG "
         case "$option" in
            h) usage_exit;;
            s) export BYPASS_STOP=YES;;
            o) export ORACLE_SID="$OPTARG"
               echo "ORACLE_SID=$ORACLE_SID";;
            b) export cmd='noaudit'
               unset  cmd_by_access
               export cmd_audit_trail='NONE'
               export cmd_audit_sys_operations='FALSE' ;;
           \?) eval print -- "ERROR:" \$$(( OPTIND - 1 )) \
                  "option is not a supported switch."
               usage_exit;;
         esac
      done
      echo "ORACLE_SID = $ORACLE_SID"
      [[ -n $ORACLE_SID ]] || usage_exit
      # . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
      echo "CMD = $cmd "

   func_check_user
   check_db_running
   func_check_required_files
   func_set_OH
   func_sw_version
   func_query_init_ora_parms
   func_set_audit_trail
   func_audit_sys_operations
   func_create_sql_scripts
   removal_create_sql_scripts
   removal_noaudit_stmt  #TODO why does this again set AUDIT_TRAIL
   func_run_sqlplus
   func_cycle_database
   echo
   echo "$Script_name: SCRIPT SUCCESSFULLY COMPLETED.  $(date) See log $LOG "
} 2>&1 | tee -a $LOG
