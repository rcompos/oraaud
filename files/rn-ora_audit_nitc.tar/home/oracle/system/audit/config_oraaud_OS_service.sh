#!/usr/bin/env ksh
#
# File: /home/oracle/system/audit/config_oraaud_OS_service.sh
#
#  VERSION:  1.0
#  DATE:  11/28/2015
#
#  US Government Users Restricted Rights
#
# Purpose:
#   Create Linux service that respawns scp_audit.sh

export Script_name=$(basename $0)
mkdir /home/oracle/system/audit/.audit 2>/dev/null
chown oracle.oinstall /home/oracle/system/audit/.audit
chmod 700 /home/oracle/system/audit/.audit
umask 002
export LOG=/home/oracle/system/audit/.audit/install_ora_audit.sh

{
   echo "  Setup the /etc/init/oraaud.conf"

   if [[ $(whoami) != root ]]; then
      echo "ERROR: run as user root"
   fi

   echo "Make log dir"
   mkdir /var/log/oracle_audit 2> /dev/null
   chown oracle.oinstall /var/log/oracle_audit 2> /dev/null

      cat > /etc/init/oraaud.conf <<\EOF
description "Oracle Audit SCP Service"

start on filesystem or runlevel [2345]
stop on runlevel [!2345]

respawn
#respawn limit unlimited

exec /bin/su - oracle -c /home/oracle/system/audit/scp_audit.sh >> /var/log/scp_audit.sh.log 2>&1
EOF
   chmod 644 /etc/init/oraaud.conf
   chown root.root /etc/init/oraaud.conf
     
   start oraaud

   echo "Sleeping 10 and checking if service is still running"
   sleep 10
   cnt=$(ps -ef | grep [s]cp_ -c)
   if ((cnt<1)); then
      echo "ERROR: expected scp_audit.sh to run after 10 seconds"
   fi

   echo "$Script_name:  SCRIPT COMPLETED SUCCESSFULLY $(date) Log is $LOG"
} 2>&1 | tee $LOG
