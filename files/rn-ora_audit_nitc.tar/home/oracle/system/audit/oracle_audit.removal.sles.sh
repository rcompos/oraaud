#!/usr/bin/env ksh
#
#  @(#)fs615/db/ora/src/system/oracle_audit.removal.sles.sh, ora, build5_3, build5_3g,1.3:4/12/10:18:21:37
#  VERSION:  1.3
#  DATE:  4/12/10:18:21:37
#
#  (C) COPYRIGHT International Business Machines Corp. 2010
#  All Rights Reserved
#  Licensed Materials - Property of IBM
#
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# Purpose:
#    Revoke auditing from a database
#
# Requires:  ORACLE_SID be set
#            User must run as SLES user oracle
#
# WARNING: User is required to review for errors.

if [[ $(whoami) != oracle ]]; then
   echo "ERROR: run as oracle"
   exit 1
fi

if ! ps -ef | grep [o]ra_pmon_${ORACLE_SID}$; then
   echo "ERROR: SID '$ORACLE_SID' is not currently running"
   exit 1
fi

file=$ORACLE_HOME/dbs/init${ORACLE_SID}.ora
if [[ -f $file ]]; then
   TS=$(date "+%Y-%m-%d:%H:%M:%S")
   cp -p $file $file.$TS
   egrep -v "^audit_trail|^audit_sys_operations" $file.$TS > $file
fi


cat > /tmp/ora_audit.sql <<\EOF
set head off
set feed off
set sqlprompt '-- '
spool /tmp/remove_auditing.sql
   --select 'NOAUDIT '||privilege||';' from DBA_SYS_PRIVS WHERE GRANTEE='DBA';
   --select 'NOAUDIT ALL BY '||grantee||';' from dba_role_privs where 
   --    granted_role='DBA' and grantee <> 'SYS';

select 'noaudit ' || AUDIT_OPTION || ';' from DBA_STMT_AUDIT_OPTS 
    where user_name is null;

   --select 'noaudit ' || AUDIT_OPTION || ' by ' || user_name || ';' from DBA_STMT_AUDIT_OPTS 
   --    where user_name is not null;
spool off
set feed on
set head on
set echo on
set sqlprompt 'SQL> '
spool /tmp/audit_errors.$ORACLE_SID.lst
alter system reset audit_trail          scope=spfile sid='*';
alter system reset audit_sys_operations scope=spfile sid='*';
alter system reset audit_syslog_level   scope=spfile sid='*';
@/tmp/remove_auditing.sql
select 'SELECT_COUNT_DBA_STMT_AUDIT_OPTS='||count(*) from DBA_STMT_AUDIT_OPTS;
shutdown immediate
startup
show parameter audit
spool off
exit
EOF

sqlplus "/ as sysdba" @/tmp/ora_audit.sql
if ! grep SELECT_COUNT_DBA_STMT_AUDIT_OPTS=0 /tmp/audit_errors.$ORACLE_SID.lst
then
   echo "ERROR: some privileges not revoked"
   echo "Please do these commands for a list of existing audited priviledges
           sqlplus / as sysdba
              select * from DBA_STMT_AUDIT_OPTS;"
   exit 1
else
   echo "SCRIPT SUCCESSFULLY COMPLETED."
fi
