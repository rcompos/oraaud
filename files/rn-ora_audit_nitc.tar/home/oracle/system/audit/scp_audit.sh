#!/usr/bin/env ksh
# # Per DG0141
# # List of privileges to audit
# 
#
#  scp_audit.sh
#  VERSION:  1.30
#  DATE:  9/17/12
#   Last Update Date:  3/28/13
#   Last Update Date:  11/27/15
#  Author: - Jim McBride 
#  Contributing Author: - Henry Steinhauer 
#
#  US Government Users Restricted Rights - Use, duplication or
#  disclosure restricted
#
# Purpose:
#    Write Oracle audit logs remotely.
#
# Regression tests:
#    Remote directory full
#    DNS to remote server fails
#    Fewer than 8000 characters of file names to send
#    More than 8000 characters of file names to send
#  Updates - Mar 05, 2014 
#    Redo logic around sending .aud files - complete and partial. 
#    Redo logic for how often to look at full directories.  every xx cycles. 
#    Change location of scp_audit.log to /var/log/oracle_audit/
#    change to purge temp audit files after 24 hours as they are no longer needing to be there. 
#  Updates - Nov 27, 2015
#    Don't loop through all files to check dates. Instead, compute minutes then use -mmin in find command

function prevent_dual_script_instances {
   file=scp_audit.sh
   if ps -ef | grep $file$ | grep -Ev 'root|grep' | grep -v "^[o]racle *$$ *.*ksh .*$file$"; then
      echo "Found an instance already running, skipping..."
      exit 1
   fi
}

function set_envars {
   echo "== Set envars"
   umask 077
   if [[ -z $INTERVAL ]]; then
      export INTERVAL=120  # Sleep time between writing to logger
   fi
   export LOG=/var/log/oracle_audit/scp_audit.log.$(date "+%Y-%m-%d")
   export SIDS=$(ps -ef | grep [p]mon | sed '/+ASM/d;s|.*ora_[p]mon_||')
   export MARKER_OLDER=/home/oracle/system/audit/.audit_marker_late.txt
   export MARKER_NEWER=/home/oracle/system/audit/.audit_marker_newer.txt
   export MARKER_NEWER_PENDING=/home/oracle/system/audit/.audit_marker_newer_pending.txt
   export LSOF=/home/oracle/system/audit/.scp_audit.sh.lsof
   export IPC_FILE=/home/oracle/system/audit/.audit_ipc.txt
   export FIND_CMD=/home/oracle/system/audit/.audit_find_mtime-1.sh
   
   if [[ $(host $(hostname) ) == *fs.usda.gov* ]]; then
      export DEST_DIR=/app/home/nfadmin/allaud
      export SCP_USER=S_SIEM-OracleLogs
      export SCP_HOST=fsxopsx0024.edc.ds1.usda.gov
   elif [[ $(host $(hostname) ) == *mci.fs.fed.us* ]]; then
      export DEST_DIR=/nfx/home/nfadmin/allaud
      export SCP_USER=svc_nfxscplogs
      export SCP_HOST=slornetf2
   else
      export DEST_DIR=/nfx/home/nfadmin/allaud
      export SCP_USER=svc_nfxscplogs
      export SCP_HOST=slornetf
   fi
   export AUDIT_AWK=/home/oracle/system/audit/audit.awk
}

function required_files {
   echo "== Required files"
   if [[ ! -s /home/oracle/system/audit/oraenv.usfs ]]; then
      cat >   /home/oracle/system/audit/oraenv.usfs <<\EOF
#  @(#)fs615/db/ora/rman/linux/rh/oraenv.usfs, ora, build6_1, build6_1a,1.3:11/12/11:21:03:28
#  VERSION:  1.3
#  DATE:  11/12/11:21:03:28
#
# 
# Purpose: Source this file to get an ORACLE_HOME by looking up ORACLE_SID in /etc/oratab
#          Sets ORACLE_HOME regardless of RAC or stand-alone, 10g or 11g
#          Calls the standard /usr/local/bin/oraenv
#
# Attention: Test any changes in bash, pdksh, and ksh93.
#
# Requires:
#   ORACLE_SID
#
# Results:
#   Sets envars based on ORACLE_SID:
#     ORACLE_HOME, PATH, LD_LIBRARY_PATH, etc.
#   Setting TNS_ADMIN and/or modifying PATH is left to the user

TAB="	"
# For bash, turn off shell history substitution for exclamation point
ps $$ | grep -q bash && set +H

# Determine node/instance number for RAC nodes
INSTNBR=$( ps -ef | sed "/asm_pmon_+AS[M]/!d;s|.*asm_pmon_+AS[M]||" )
if [[ -z "$INSTNBR" ]]; then
   FS615_ORATAB=/etc/oratab
   [[ $(uname) == "SunOS" ]] && FS615_ORATAB=/var/opt/oracle/oratab
   INSTNBR=$( sed "/^[ $TAB]*#/d; /^+ASM[0-9]:/!d; s|+ASM\([0-9]*\):.*|\1|" $FS615_ORATAB )
fi

# Preserve current value of ORACLE_SID
orig_ORACLE_SID=$ORACLE_SID

# If this server is a RAC node, strip instance number
# from ORACLE_SID before calling oraenv
if [[ -n "$INSTNBR" ]]; then
   export ORACLE_SID=${ORACLE_SID%${INSTNBR}}
fi

orig_ORACLE_BASE=$ORACLE_BASE
# Call oraenv to set PATH, ORACLE_HOME,
#  LD_LIBRARY_PATH (for RDBMS servers), etc.
# Setting TNS_ADMIN and/or modifying PATH is left to the user
which dbhome > /dev/null 2>&1 || PATH=$PATH:/usr/local/bin/
ORAENV_ASK=NO
. /usr/local/bin/oraenv < /dev/null

# Restore original value of ORACLE_SID
export ORACLE_SID=$orig_ORACLE_SID

# If ORACLE_HOME was set to the ~oracle default, then oraenv failed;
#  try again with original value of ORACLE_SID as restored above
if [[ "$ORACLE_HOME" == ~oracle ]]; then
   . /usr/local/bin/oraenv
fi
ORACLE_BASE=$orig_ORACLE_BASE
EOF
      chown oracle.dba /home/oracle/system/audit/oraenv.usfs
      chmod 700        /home/oracle/system/audit/oraenv.usfs
   fi
}

function set_AUDIT_DIR {
   export AUDIT_DIR=$(
      for dir in /opt/oracle/admin/*/adump; do
         [[ ! -L $dir && -d $dir ]] && echo $dir
      done)
   # JTM: 11/30/15 I'm commenting out this dynamic code because a database might be down.
   if [[ 0 == 1 ]]; then
      # Input: $SIDS
      # Output: /home/oracle/system/audit/.aud.$ORACLE_SID.audit_file_path
      echo "== Set AUDIT_DIR"
      SQL=/home/oracle/system/audit/select_vsession.sql
      echo "set head off
            set feed off
            set pages 0
            select value from v\$parameter where name='audit_file_dest';
            exit;" > $SQL
      rm /home/oracle/system/audit/.aud.*.audit_file_path 2>/dev/null
      for ORACLE_SID in $SIDS; do
         echo "ORACLE_SID=$ORACLE_SID" >> $LOG
         AUD_PATH_LOG=/home/oracle/system/audit/.aud.$ORACLE_SID.audit_file_path
         ( # Was   s u   -   oracle
            export ORACLE_SID=$ORACLE_SID;
            . /home/oracle/system/audit/oraenv.usfs;
            export PATH=$ORACLE_HOME/bin:$PATH;
            sqlplus -S "/ AS SYSDBA" @$SQL ) \
            2>&1 | tee $AUD_PATH_LOG.lst
         AUDIT_DIR=$(grep ^/ $AUD_PATH_LOG.lst | tail -1)
         echo $(date) AUDIT_DIR=$AUDIT_DIR >> $LOG
         echo $AUDIT_DIR > $AUD_PATH_LOG | tee -a $LOG
      done
      export AUDIT_DIR=$(cat /home/oracle/system/audit/.aud.*.audit_file_path)
   fi
}

function create_awk_file {
echo "== Create awk file"
cat > $AUDIT_AWK <<\EOF
BEGIN {
   flag=0;
   golive=0;
   if (DEBUG==1) print "BEGT=" BEGT;
   if (DEBUG==1) print "ENDT=" ENDT;
}
{
   if ( $0 ~ /^[SMTWF][uoehra][neduit] [A-Z][a-z][a-z] [ 0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9] 20[0-9][0-9]/ ) {
      flag=1;
      golive=0;
   }
   if (flag == 0) print $0
   if ( flag > 0 ) {
      if ( flag == 1 ) {
         while (1==1) {
            if ($2=="Jan") {mon="01"; break;}
            if ($2=="Feb") {mon="02"; break;}
            if ($2=="Mar") {mon="03"; break;}
            if ($2=="Apr") {mon="04"; break;}
            if ($2=="May") {mon="05"; break;}
            if ($2=="Jun") {mon="06"; break;}
            if ($2=="Jul") {mon="07"; break;}
            if ($2=="Aug") {mon="08"; break;}
            if ($2=="Sep") {mon="09"; break;}
            if ($2=="Oct") {mon="10"; break;}
            if ($2=="Nov") {mon="11"; break;}
            if ($2=="Dec") {mon="12"; break;}
            mon="Error"; break;
         }
         hhmmss=substr($4,1,2) substr($4,4,2) substr($4,7,2);
         dd=$3
         if (length(dd) == 1) dd="0" dd;
         # 5=yyyy mon dd hhmmss
         ts=$5 mon dd hhmmss;
         if (DEBUG==1) print "HERE ts2=" ts "|" $0;
         if ( (BEGT <= ts && ts <= ENDT) || $0 ~ /^Audit file/ ){
            golive=1;
            #DEBUG print ts "|" $0;
            print $0;
         }
      } else {
         if (golive != 0)
            print $0;
      }
      flag=flag+1;
   }
}
EOF
}

function sub_function_scp_aud_env_FILES {
   # Purpose: Repeat a remote copy if space on the remote server is full.
   # Input: $FILES, $INTERVAL
   # Local: $rc, $FUNCTION_LOG
   echo ".. Sub func scp files"
   export FUNC_LOG=/home/oracle/system/audit/.audit_function_log
   export LOG=/var/log/oracle_audit/scp_audit.log.$(date "+%Y-%m-%d")

   while true; do
      echo scp $FILES $SCP_USER@$SCP_HOST:$DEST_DIR >> $LOG 2>&1
      scp $FILES $SCP_USER@$SCP_HOST:$DEST_DIR 2>&1 | tee $FUNC_LOG 2>&1 >> $LOG
      if grep -q ' No space left on device' $FUNC_LOG; then
         echo "Remote destination out of space. Sleeping $INTERVAL seconds now $(date)" >> $LOG
         sleep $INTERVAL
         continue;
      elif grep -q '^scp:' $FUNC_LOG; then
         if grep -q '^scp: .*Permission denied$' $FUNC_LOG; then
            echo "scp error of 'Permission denied' found.  Continuing since destination server likely already has the logs. $(date)" >> $LOG
            break;
         else
            echo "General scp error. $(date)" >> $LOG
            echo "Sleeping $INTERVAL seconds now, then retrying same files $(date)" >> $LOG
            sleep $INTERVAL
            continue;
         fi
      elif grep -q '^ssh:' $FUNC_LOG; then
         echo "General ssh error. (Check DNS resolution.) $(date)" >> $LOG
         echo "Sleeping $INTERVAL seconds now, then retrying same files $(date)" >> $LOG
         sleep $INTERVAL
         continue;
      else
         break;
      fi
   done >> $LOG 2>&1
}

function sub_function_purge_full_file_systems {
   echo ".. Sub func purge full file systems"
   #   Add logic to not check every interval but every xx interval. 

   # test only at 1 am 

   Chk_hr=$(date +"%H"); 
   if [[ $Chk_hr == "01" ]]; then    
      export MAX_DF_FULL=70
      echo ".. Checking for full admump directory ($MAX_DF_FULL%)"
      #
      # purge any *adump*  entries older than 24 hours. 
      #   
     
      find $AUDIT_DIR -name "*.adump*" -mtime +1 | xargs rm -rf
              
      echo "Searching for $MAX_DF_FULL% full directories" >> $LOG
      for dir in $AUDIT_DIR; do
         if [[ $dir == /opt/oracle/admin/* ]]; then
            echo "Checking fullness of '$dir'" >> $LOG
            percent_full=$(df -Ph $dir | tail -1 | tr ' ' '\n' | sed '/%/!d;s|%||')
            if ((percent_full>MAX_DF_FULL)); then
               echo "'$dir' is '$percent_full' percent full which is MORE than '$MAX_DF_FULL' percent, so removing 10% of the files $(date)" >> $LOG
               cnt=$(/bin/ls -l $dir | grep 'ora_.*\.aud' | \
                     awk '{if ($5 != 0) print $0}' | wc -l)
               echo "Found 'cnt=$cnt' count non empty files in '$dir'" >> $LOG
               cnt=$((cnt*10/100))
               echo "Found 'cnt=$cnt' count files to zero out." >> $LOG
               /bin/ls -altr $dir | grep 'ora_.*\.aud' | \
                     awk "{if (\$5 != 0) print \"$dir/\" \$9}" | head -$cnt | \
                        while read file; do 
                           #OLD  echo "Removing '$file'" >> $LOG; 
                           #OLD  rm $file >> $LOG 2>&1
                           echo "Zeroing out '$file'" >> $LOG; 
                           time_stamp=$(stat $file | sed '/Modify/!d; s|Modify: ||; s|[0-9][0-9]\..*||;s|[^0-9]||g')
                           >$file;
                           echo "Doing 'touch -t$time_stamp $file' $(date)" >> $LOG 2>&1
                           touch -t$time_stamp $file >> $LOG 2>&1
                        done
            else
               echo "'$dir' is '$percent_full' percent full which is less than '$MAX_DF_FULL' percent, so skipping it $(date)" >> $LOG
            fi
         fi
      done
   fi 
}

function aud_main {
   echo "Starting $0"
   echo "Logs are at /var/log/oracle_audit/scp_audit.log.<date>"
   while true; do
      export LOG=/var/log/oracle_audit/scp_audit.log.$(date "+%Y-%m-%d")
      echo "Starting scan. $(date)" >> $LOG
      echo "Purging old logs $(date)" >> $LOG
      find /var/log/oracle_audit/scp_audit.log.* -mtime +7   2> /dev/null | xargs rm 2>/dev/null
      echo "Discovering directories containing audit files $(date)" >> $LOG
      echo $(date) AUDIT_DIR=$AUDIT_DIR >> $LOG
      if [[ -z $AUDIT_DIR ]]; then
         echo "ERROR: scp_audit.11g.sh, \$AUDIT_DIR is empty"
         sleep 300
         exit 1
      fi 
      # find $AUDIT_DIR -type f -name "*.aud" 2> /dev/null | while read file; do
      # If MARKER_NEWER is missing, then send all logfiles (date it very old)
      # Either way, save MARKER_NEWER (rename MARKER_NEWER to MARKER_OLDER)
      # then save the current time (create a new MARKER_NEWER with current date and time)
      # Finally, send all files newer than marker_late
      if [[ ! -f $MARKER_NEWER ]]; then
         #  Marker_Newer does not exist - so pick up history  # Stienhauer
         if [[ $(host $(hostname) ) != *wrk.fs.usda.gov* ]]; then
            echo "$(date) touch -t197001010000 $MARKER_NEWER" >> $LOG
            touch -t197001010000 $MARKER_NEWER
            # if production - then make epoc time as start of unix  # Stienhauer
         else
            #  not production - only go back 24 hours.  # Stienhauer
            echo "$(date) Find the oldest file that is within 24 hours old:" >> $LOG
            echo 'find "$@" -mtime -1 -type f' > $FIND_CMD
            chmod 700 $FIND_CMD
            day_old=$(for dir in $AUDIT_DIR; do
                  #echo "dir=$dir"
                  /bin/ls -1 -tr $dir | tr ' ' '\n' | sed "s|^|$dir/|"
               done | grep aud$ | xargs $FIND_CMD | tee -a $LOG | \
               xargs /bin/ls -dl --time-style=long-iso | awk '{print $6 $7 " " $8}' | \
               sed 's|[-:]*||g;' | sort -rn | tee -a $LOG | tail -1 | \
               sed 's|.* ||'
            )
            echo "$(date) /bin/ls -dl --time-style=long-iso $day_old" >> $LOG
            echo "$(date) $(/bin/ls -dl --time-style=long-iso $day_old)" >> $LOG
            echo "$(date) cp -p \$day_old \$MARKER_NEWER" >> $LOG
            echo "$(date) cp -p $day_old $MARKER_NEWER" >> $LOG
            cp -p $day_old $MARKER_NEWER >> $LOG 2>&1 
            if [[ $? != 0 ]]; then
               rm -f $MARKER_NEWER
               touch -t197001010000 $MARKER_NEWER
            fi
         fi
      fi
      mv $MARKER_NEWER $MARKER_OLDER   
      touch $MARKER_NEWER_PENDING
      sleep 2 # Wait so that the newer marker file can be older than audit file 
              # that might still be changing.
      export FILES=''
      export cnt=0
      export HOSTNAME=$(hostname)
      #OLD lsof | grep '\.aud'  | awk '{print $9}' > $LSOF
      echo "ls -l $MARKER_OLDER $MARKER_NEWER_PENDING" >> $LOG
      ls -l $MARKER_OLDER $MARKER_NEWER_PENDING >> $LOG
      echo "stat -c "%y" $MARKER_OLDER" >> $LOG
      stat -c "%y" $MARKER_OLDER >> $LOG
      echo "stat -c "%y" $MARKER_NEWER_PENDING" >> $LOG
      stat -c "%y" $MARKER_NEWER_PENDING >> $LOG
      export BEGTIME=$(stat -c "%y" $MARKER_OLDER | sed 's/\..*//;s/[- :]//g') #like 20120904152414
      echo "BEGTIME=$BEGTIME" >> $LOG
      export ENDTIME=$(stat -c "%y" $MARKER_NEWER_PENDING | sed 's/\..*//;s/[- :]//g')
      echo "ENDTIME=$ENDTIME" >> $LOG
         
      ts_now=$(date "+%s")
      ts_mark=$(date -d "$(stat $MARKER_OLDER | sed '/^Modify/!d; s/^Modify: //')" '+%s')
      find_mins=$(( (ts_now-ts_mark)/60 + 2 ))

      echo "find_mins=$find_mins" | tee -a $LOG
      cnt0=$(find $AUDIT_DIR -maxdepth 1 -name "*.aud" -mmin -$find_mins | grep "^[^\.]*.aud" | wc -l)
      echo "Files in minute time range: $cnt0" | tee -a $LOG
      find $AUDIT_DIR -maxdepth 1 -name "*.aud" -mmin -$find_mins | grep "^[^\.]*.aud" | while read file; do
         #echo "file=$file"
         if [[ $file -nt $MARKER_OLDER ]] && [[ $file -ot $MARKER_NEWER_PENDING ]]; then
            echo "Found file $(date): $file" >> $LOG
            file_new=$( while true; do
               export randpass=a$(dd if=/dev/urandom  count=14 bs=1 2>/dev/null | \
                   od -h | head -1 | sed 's|^00* ||;s| ||g')
               file_new="$(
                  echo "$file" | sed 'h; s|\(.*\)\/.*|\1|; s|.*\/\([^\]*/[^/]*$\)|\1|; s|/|.|g; x; s|\.aud$|.|; G;' \
                        | tr -d '\n'; echo
               ).$randpass.$HOSTNAME.aud"
               if [[ -f $file_new ]]; then
                  echo "Can't rename $file to $file_new since the latter exists.  Itterating..." >> $LOG
               else
                  echo $file_new
                  break
               fi
            done )
            #OLD echo "Renaming $file to $file_new" >> $LOG
            #OLD mv $file $file_new 2>&1 >> $LOG
            #OLD file=$file_new
            echo "awk -v BEGT=$BEGTIME -v ENDT=$ENDTIME -f $AUDIT_AWK $file > $file_new" >> $LOG
            awk -v BEGT=$BEGTIME -v ENDT=$ENDTIME -f $AUDIT_AWK $file > $file_new
            # scp $file oracleaudlog@slornetf:$DEST_DIR
            if ((   $(( ${#FILES}+${#file_new} )) > 8000  )); then 
               sub_function_scp_aud_env_FILES
               export FILES=""
            fi
            export FILES="$FILES $file_new"
         else
            ((cnt=cnt+1))
         fi
         echo "export FILES='$FILES'" | sed 's|= |=|' > $IPC_FILE
         echo "export cnt=$cnt" >> $IPC_FILE
         chmod 700 $IPC_FILE
      done
      . $IPC_FILE
      if [[ -n "$FILES" ]]; then
         sub_function_scp_aud_env_FILES
         export FILES=""
      fi
      for dir in $AUDIT_DIR; do
         sub_function_purge_full_file_systems
      done
      mv $MARKER_NEWER_PENDING $MARKER_NEWER
      echo "Skipped $cnt files previously sent. $(date)" >> $LOG
      echo "Ending scan.  Sleeping $INTERVAL seconds now $(date)" >> $LOG
      #DEBUG echo "Pause 1"; read q; #exit 1
      sleep $INTERVAL
   done
}

prevent_dual_script_instances
set_envars
required_files
set_AUDIT_DIR
create_awk_file
aud_main 
